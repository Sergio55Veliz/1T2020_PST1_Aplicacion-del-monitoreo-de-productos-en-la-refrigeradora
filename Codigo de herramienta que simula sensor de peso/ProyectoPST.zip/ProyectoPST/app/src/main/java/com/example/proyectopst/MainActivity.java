package com.example.proyectopst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private String server = "https://flightsregister.000webhostapp.com/conexion_arduino.php?peso=";
    private EditText pesos;
    private TextView text;
    private String peso;
    private String query;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pesos=(EditText) findViewById(R.id.editTextTextPersonName);
        text=(TextView) findViewById(R.id.textView);

    }

    public void setPeso(View view){
        String[] resultado = null;
        peso=pesos.getText().toString();
        text.setText(peso);

        try {
            String[] datos = new String[]{
                    "query",
                    server,
                    //"INSERT INTO Registro-Alimento (`id`, `idSensor`, `idRefri`, `peso`, `fecha`, `hora`) VALUES (NULL, '"+ IdSensor +"', '"+ IdRefri +"', '"+ peso +"', CURRENT_DATE(), CURRENT_TIME())"
                    "Select * From Registro-Alimento"
            };
            AsyncQuery async = new AsyncQuery();
            resultado = async.execute(datos).get();
            //text.setText(resultado[0].toString());
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void peso(View v){
        peso=pesos.getText().toString();
        text.setText(peso);
        query=server+peso;
        Intent i = new Intent(this, MainActivity2.class );
        i.putExtra("url", query);
        startActivity(i);
    }

}
